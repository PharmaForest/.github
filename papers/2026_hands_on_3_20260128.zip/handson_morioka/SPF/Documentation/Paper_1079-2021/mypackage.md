## General Info: ##

The `%mcrTwo()` macro is the main macro of the package. 

It has one key-value parameter `m` with default value `mcrOne`.

## Examples: ##

Example 1. Basic use-case:
~~~~~~~~~~~~~~~~~~~~~~~~~~

%mcrTwo(m=mcrOne)

~~~~~~~~~~~~~~~~~~~~~~~~~~
